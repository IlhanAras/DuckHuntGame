import javafx.animation.*;
import javafx.application.Application;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.Pane;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.ArrayList;

public class Level6Class extends Application implements Methods{
    private Stage primaryStage;
    private String backgroundOption;
    private String crosshairOption;
    private Pane lvlRoot;
    private Scene lvlScene;
    private int soundCounter=0;
    private ImageView backgroundImageView;
    private int WINDOW_WIDTH;
    private int WINDOW_HEIGHT;
    private int duckSize;
    private ImageView crosshairImageView;
    private int ammoCount;
    private boolean isLevelFinished=false;
    private ArrayList<Duck> ducks=new ArrayList<>();
    private int levelNo;
    private  AudioClip hitEffect = new AudioClip(getClass().getResource("assets/effects/Gunshot.mp3").toString());


    /**
     Constructs a Level6Class object with the specified parameters.
     @param primaryStage The primary stage for the JavaFX application.
     @param levelNo The level number for Level6Class.
     @param backgroundOption The background option for the level background.
     @param crosshairOption The crosshair option for the level.
     @param duckCount The number of ducks in the level.
     @author b2210356023 ilhan aras
     @return void
     */
    public Level6Class(Stage primaryStage,int levelNo, String backgroundOption, String crosshairOption, int duckCount) {
        this.primaryStage = primaryStage;
        this.levelNo=levelNo;
        this.backgroundOption = backgroundOption;
        this.crosshairOption = crosshairOption;
        this.WINDOW_HEIGHT=DuckHunt.WINDOW_HEIGHT;
        this.WINDOW_WIDTH=DuckHunt.WINDOW_WIDTH;
        this.duckSize=DuckHunt.DUCK_SIZE;
        this.lvlRoot=new Pane();
        this.lvlScene = new Scene(lvlRoot, WINDOW_WIDTH, WINDOW_HEIGHT);
        this.ammoCount=duckCount*3;

    }

    /**
     This method is responsible for setting up the background and foreground images,
     creating multiple duck objects, and displaying the level scene.
     */
    public void levelBackgroundMaker(){
        backgroundImageView = new ImageView();
        backgroundImageView.setFitWidth(WINDOW_WIDTH);
        backgroundImageView.setFitHeight(WINDOW_HEIGHT);
        backgroundImageView.setImage(new Image("assets/background/" +backgroundOption));
        lvlRoot.getChildren().addAll(backgroundImageView);

        ducks.add(new Duck(lvlRoot,WINDOW_WIDTH/1,WINDOW_HEIGHT/3,"duck_black",WINDOW_WIDTH/200,0));
        primaryStage.setScene(lvlScene);
        primaryStage.show();

        ducks.add(new Duck(lvlRoot,WINDOW_WIDTH/20,WINDOW_HEIGHT/7,"duck_red",-WINDOW_WIDTH/200,0));
        primaryStage.setScene(lvlScene);
        primaryStage.show();

        ducks.add(new Duck(lvlRoot,WINDOW_WIDTH,WINDOW_HEIGHT/3,"duck_blue",-WINDOW_WIDTH/220,WINDOW_HEIGHT/200));
        primaryStage.setScene(lvlScene);
        primaryStage.show();

        ImageView foreground=new ImageView();
        foreground.setFitWidth(WINDOW_WIDTH);
        foreground.setFitHeight(WINDOW_HEIGHT);
        foreground.setImage(new Image("assets/foreground/" +backgroundOption));

        Text lvlText = new Text("Level "+levelNo+"/6");
        lvlText.setFont(Font.font("Arial", FontWeight.BOLD, DuckHunt.TEXTSIZE));
        lvlText.setFill(Color.ORANGE);
        lvlText.setTextAlignment(TextAlignment.CENTER);
        lvlText.setLayoutX(WINDOW_WIDTH/4.0);
        lvlText.setY(DuckHunt.TEXTSIZE);

        lvlRoot.getChildren().addAll(lvlText,foreground);

    }


    @Override
    public void start(Stage primaryStage) throws Exception {
        levelBackgroundMaker();
        crosshairImageView=makeCroshairLabel(lvlScene,crosshairImageView,crosshairOption,lvlRoot);
        Label ammoLabel=makeAmmoLabel(lvlRoot,ammoCount);


        lvlScene.setOnMouseMoved(event -> {
            crosshairImageView.setTranslateX(event.getSceneX() -20);
            crosshairImageView.setTranslateY(event.getSceneY() -20);

        });

        lvlScene.setOnMouseClicked(event -> {
            if (event.getButton() == MouseButton.PRIMARY) {

                if(!isLevelFinished && ammoCount>0){

                    ammoCount--;
                    ammoLabel.setText("Ammo: "+ammoCount);
                    hitEffect.setVolume(DuckHunt.AllMusicsVolume);
                    hitEffect.play();

                    for(int i=0; i<ducks.size(); i++){
                        double mouseX = event.getX();
                        double mouseY = event.getY();
                        double duckX = ducks.get(i).getImageView().getLayoutX() + duckSize / 2;
                        double duckY = ducks.get(i).getImageView().getLayoutY() + duckSize / 2;
                        if (Math.abs(mouseX - duckX) <= duckSize / 2 && Math.abs(mouseY - duckY) <= duckSize / 2) {

                            hitDuck(ducks.get(i),lvlRoot);
                            ducks.remove(i);
                            if(ducks.size()==0){

                                isLevelFinished=true;
                            }
                        }
                    }
                }
                if(ducks.size()==0 && isLevelFinished &&soundCounter==0){
                    AudioClip winEffect = new AudioClip(getClass().getResource("assets/effects/GameCompleted.mp3").toString());
                    winEffect.setVolume(DuckHunt.AllMusicsVolume);
                    winEffect.play();
                    soundCounter++;
                    Label flashingTextLabel = createFlashingTextLabel("YOU HAVE COMPLETED THE GAME!", "Press ENTER to play again\nPress ESC to exit");
                    flashingTextLabel.layoutXProperty().bind(lvlRoot.widthProperty().subtract(flashingTextLabel.widthProperty()).divide(2));
                    flashingTextLabel.layoutYProperty().bind(lvlRoot.heightProperty().subtract(flashingTextLabel.heightProperty()).divide(2));

                    lvlRoot.getChildren().add(flashingTextLabel);

                    lvlScene.setOnKeyPressed(eventew -> {
                        if (eventew.getCode() == KeyCode.ENTER) {
                            winEffect.stop();
                            Level1Class level1=new Level1Class(primaryStage,1,backgroundOption,crosshairOption,1);
                            try {
                                level1.start(primaryStage);
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        } else if (eventew.getCode()==KeyCode.ESCAPE) {
                            winEffect.stop();
                            WelcomeScreenClass welcomeScreenClass=new WelcomeScreenClass(primaryStage);
                            try {
                                welcomeScreenClass.start(primaryStage);
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        }
                    });
                }
                else if (ammoCount==0 && !isLevelFinished) {
                    AudioClip loseEffect=gameOverTextAndSoundMaker(lvlRoot);

                    isLevelFinished = true;
                    lvlScene.setOnKeyPressed(eventew -> {
                        if (eventew.getCode() == KeyCode.ENTER) {
                            loseEffect.stop();
                            Level1Class level1=new Level1Class(primaryStage,1,backgroundOption,crosshairOption,1);
                            try {
                                level1.start(primaryStage);
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        } else if (eventew.getCode() == KeyCode.ESCAPE) {
                            loseEffect.stop();
                            WelcomeScreenClass welcomeScreenClass=new WelcomeScreenClass(primaryStage);
                            try {
                                welcomeScreenClass.start(primaryStage);
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        }
                    });
                }
            }
        });

        primaryStage.setScene(lvlScene);
    }
}
