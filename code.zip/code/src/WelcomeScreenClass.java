import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.StackPane;
import javafx.scene.media.AudioClip;
import javafx.stage.Stage;


public class WelcomeScreenClass extends Application implements Methods{

    public int WINDOW_WIDTH = DuckHunt.WINDOW_WIDTH;
    public int WINDOW_HEIGHT = DuckHunt.WINDOW_HEIGHT;
    private String BACKGROUND_MUSIC_PATH = "assets/effects/Title.mp3";
    private String TITLE = "HUBBM Duck Hunt";
    private String FAVICON_PATH = "assets/favicon/1.png";
    private String WELCOME_PATH = "assets/welcome/1.png";
    private String FLASHING_TEXT_LINE_1 = "PRESS ENTER TO PLAY";
    private String FLASHING_TEXT_LINE_2 = "PRESS ESC TO EXIT";
    private AudioClip backgroundMusic;
    private Scene welcomeScene;
    StackPane welcomeRoot;


    /**
     Creates an instance of the WelcomeScreenClass.
     @param primaryStage The primary stage of the application.
     */
    public WelcomeScreenClass(Stage primaryStage) {
        primaryStage.setTitle(TITLE);

        primaryStage.getIcons().add(new Image(FAVICON_PATH));

        welcomeRoot = new StackPane();
        welcomeScene = new Scene(welcomeRoot, WINDOW_WIDTH, WINDOW_HEIGHT);
        primaryStage.setScene(welcomeScene);

        ImageView welcomeImageView = new ImageView(WELCOME_PATH);
        welcomeImageView.setFitWidth(WINDOW_WIDTH);
        welcomeImageView.setFitHeight(WINDOW_HEIGHT);
        welcomeRoot.getChildren().add(welcomeImageView);

        Label flashingTextLabel = createFlashingTextLabel(FLASHING_TEXT_LINE_1,FLASHING_TEXT_LINE_2);
        welcomeRoot.getChildren().add(flashingTextLabel);
    }


    @Override
    public void start(Stage primaryStage) throws Exception {

        welcomeScene.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ENTER) {
                OptionScreenClass optionScreenClass =new OptionScreenClass(primaryStage,backgroundMusic);
                try {
                    optionScreenClass.start(primaryStage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            } else if (event.getCode() == KeyCode.ESCAPE) {
                primaryStage.close();
            }
        });

        backgroundMusic = new AudioClip(getClass().getResource(BACKGROUND_MUSIC_PATH).toString());
        backgroundMusic.setCycleCount(AudioClip.INDEFINITE);
        backgroundMusic.setVolume(DuckHunt.AllMusicsVolume);
        backgroundMusic.play();

        primaryStage.show();
    }
}
