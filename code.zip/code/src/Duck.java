import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.util.Duration;

public class Duck {
    private ImageView imageView;
    private Pane pane;
    private int velocityX;
    private int velocityY;
    private Timeline movement;
    private Timeline timeline;
    private String duckColor;
    private int duckSize;
    private  Image upRightWingUpper ;
    private Image upRightWingMiddle ;
    private Image upRightWingDown ;
    private Image wingUpImage ;
    private Image wingMiddleImage ;
    private Image wingDownImage ;
    private int ycoor;
    private int xcoor;


    /**
     Constructs a Duck object with the specified parameters.
     @param pane the parent Pane object where the Duck will be displayed
     @param xcoor the initial X-coordinate of the Duck's position
     @param ycoor the initial Y-coordinate of the Duck's position
     @param duckColor the color of the Duck
     @param velocityX the velocity of the Duck in the X direction
     @param velocityY the velocity of the Duck in the Y direction
     @author b2210356023 ilhan aras
     */
    public Duck(Pane pane,int xcoor,int ycoor,String duckColor,int velocityX,int velocityY) {
        this.pane = pane;
        this.velocityX = velocityX;
        this.velocityY = velocityY;
        this.duckColor=duckColor;
        this.xcoor=xcoor;
        this.ycoor=ycoor;
        this.duckSize=DuckHunt.DUCK_SIZE;

        this.upRightWingUpper = new Image("assets/"+duckColor+"/1.png");
        this.upRightWingMiddle = new Image("assets/"+duckColor+"/2.png");
        this.upRightWingDown = new Image("assets/"+duckColor+"/3.png");
        this.wingUpImage = new Image("assets/"+duckColor+"/4.png");
        this.wingMiddleImage = new Image("assets/"+duckColor+"/5.png");
        this.wingDownImage = new Image("assets/"+duckColor+"/6.png");

        makeFirstDuckImage();
        duckAnimationMaker();


    }

    /**
     Controls the animation of the Duck's wings and movement.
     The animation is created using a Timeline and consists of four key frames, each representing a different wing position.
     The movement is handled by calling the move() method.
     The Duck's ImageView is added to the parent pane, and the animation and movement timelines are started.
     This method is private and is called internally within the Duck class.
     @author b2210356023
     @return void
     */
    private void duckAnimationMaker(){
        timeline = new Timeline(
                new KeyFrame(Duration.ZERO, e -> {
                    if (velocityX > 0 && velocityY > 0) {
                        imageView.setImage(upRightWingUpper);
                    }
                    else if (velocityX < 0 && velocityY > 0) {
                        imageView.setImage(upRightWingUpper);
                    }
                    else if (velocityX > 0 && velocityY < 0) {
                        imageView.setImage(upRightWingUpper);
                    }
                    else if (velocityX < 0 && velocityY==0){
                        imageView.setImage(wingUpImage);

                    }
                    else if (velocityX > 0 && velocityY==0) {
                        imageView.setImage(wingUpImage);

                    } else {
                        imageView.setImage(upRightWingUpper);

                    }
                    move();
                }),
                new KeyFrame(Duration.millis(250), e -> {
                    if (velocityX > 0 && velocityY > 0) {
                        imageView.setImage(upRightWingMiddle);
                    }
                    else if (velocityX < 0 && velocityY > 0) {
                        imageView.setImage(upRightWingMiddle);

                    }
                    else if (velocityX < 0 && velocityY==0){
                        imageView.setImage(wingMiddleImage);

                    }
                    else if (velocityX > 0 && velocityY==0) {
                        imageView.setImage(wingMiddleImage);

                    }
                    else if (velocityX > 0 && velocityY < 0) {
                        imageView.setImage(upRightWingMiddle);
                    }
                    else {
                        imageView.setImage(upRightWingMiddle);
                    }
                    move();
                }),
                new KeyFrame(Duration.millis(500), e -> {
                    if (velocityX > 0 && velocityY > 0) {
                        imageView.setImage(upRightWingDown);
                    }
                    else if (velocityX < 0 && velocityY > 0) {
                        imageView.setImage(upRightWingDown);

                    }
                    else if (velocityX < 0 && velocityY==0){
                        imageView.setImage(wingDownImage);

                    }
                    else if (velocityX > 0 && velocityY==0) {
                        imageView.setImage(wingDownImage);

                    }
                    else if (velocityX > 0 && velocityY < 0) {
                        imageView.setImage(upRightWingDown);
                    }
                    else {
                        imageView.setImage(upRightWingDown);

                    }
                    move();
                }),
                new KeyFrame(Duration.millis(750), e -> {
                    if (velocityX > 0 && velocityY > 0) {
                        imageView.setImage(upRightWingUpper);

                    } else if (velocityX < 0 && velocityY > 0) {
                        imageView.setImage(upRightWingUpper);

                    } else if (velocityX > 0 && velocityY < 0) {
                        imageView.setImage(wingMiddleImage);
                    }
                    else if (velocityX < 0 && velocityY==0){
                        imageView.setImage(wingUpImage);

                    }
                    else if (velocityX > 0 && velocityY==0) {
                        imageView.setImage(wingUpImage);

                    }
                    else {
                        imageView.setImage(wingUpImage);
                    }
                    move();
                })
        );


        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();
        pane.getChildren().add(imageView);

        movement = new Timeline(
                new KeyFrame(Duration.millis(16), e -> move())
        );
        movement.setCycleCount(Timeline.INDEFINITE);
        movement.play();
    }

    /**

     Creates the initial image of the Duck based on its velocity.
     The image is set to the appropriate wing position and scaled accordingly.
     The ImageView's fit width and fit height are set to the duckSize.
     The ImageView's layout position is set to the specified X and Y coordinates.
     This method is private and is called internally within the Duck class.
     @author b2210356023 ilhan aras
     @return void
     */
    private void makeFirstDuckImage() {
        if(velocityX<0 && velocityY<0){
            imageView = new ImageView(upRightWingUpper);
            imageView.setScaleX(imageView.getScaleX() * -1);
        } else if (velocityX<0 && velocityY>0) {
            imageView = new ImageView(upRightWingUpper);
            imageView.setScaleX(imageView.getScaleX() * -1);
            imageView.setScaleY(imageView.getScaleY() * -1);
        }else if (velocityX>0 && velocityY>0) {
            imageView = new ImageView(upRightWingUpper);
            imageView.setScaleY(imageView.getScaleY() * -1);
        }else if (velocityX>0 && velocityY<0) {
            imageView = new ImageView(upRightWingUpper);
        } else if (velocityY==0 && velocityX<0) {
            imageView = new ImageView(wingUpImage);
            imageView.setScaleX(imageView.getScaleX() * -1);
        } else if (velocityY==0 && velocityX>0) {
            imageView = new ImageView(wingUpImage);
        }
        imageView.setFitWidth(duckSize);
        imageView.setFitHeight(duckSize);
        imageView.setLayoutY(ycoor);
        imageView.setLayoutX(xcoor);

    }
    /***
     * Moves the ImageView object based on the current velocity in the X and Y directions.
     * If the ImageView reaches the boundaries of the parent pane, it will reverse its scale and change the direction of its velocity accordingly.
     * If the ImageView reaches the left or right boundary and has a non-zero velocity in the Y direction, it will reverse its scale and change the direction of its velocity in the X direction.
     * If the ImageView reaches the top or bottom boundary and has a non-zero velocity in the X direction, it will reverse its scale and change the direction of its velocity in the Y direction.
     * If the ImageView reaches the left or right boundary and has a zero velocity in the Y direction, it will reverse its scale and change the direction of its velocity in the X direction.
     * Note: The method assumes that the ImageView and parent pane (pane) have been properly initialized and positioned.
     *
     * @return void
     * @author b2210356023 ilhan aras
     */
    public void move() {
        imageView.setLayoutX(imageView.getLayoutX() + velocityX);
        imageView.setLayoutY(imageView.getLayoutY() + velocityY);

        double x = imageView.getLayoutX();
        double y = imageView.getLayoutY();

        if(x<=0 && velocityY<0 && velocityX<0){
            imageView.setScaleX(imageView.getScaleX() * -1);
            velocityX *= -1;
        }  else if(x<=0 && velocityY>0 && velocityX<0){
            imageView.setScaleX(imageView.getScaleX() * -1);
            velocityX *= -1;
        }
        else if (x >= pane.getWidth() - imageView.getImage().getWidth() && velocityY<0 && velocityX>0) {
            imageView.setScaleX(imageView.getScaleX() * -1);
            velocityX *= -1;
        }
        else if (x >= pane.getWidth() - imageView.getImage().getWidth() &&velocityY>0 && velocityX>0) {
            imageView.setScaleX(imageView.getScaleX() * -1);
            velocityX *= -1;
        }
        else if (y<=0 && velocityX<0 && velocityY<0) {
            imageView.setScaleY(imageView.getScaleY() * -1);
            velocityY*= -1;
        }
        else if (y<=0 && velocityX>0 && velocityY<0) {
            imageView.setScaleY(imageView.getScaleY() * -1);
            velocityY*= -1;
        }
        else if (y >= pane.getHeight() - imageView.getImage().getHeight() && velocityX<0 && velocityY>0) {
            imageView.setScaleY(imageView.getScaleY() * -1);
            velocityY*= -1;
        }
        else if (y >= pane.getHeight() - imageView.getImage().getHeight() && velocityX>0 && velocityY>0) {
            imageView.setScaleY(imageView.getScaleY() * -1);
            velocityY*= -1;
        } else if (x<=0 && velocityX<0 && velocityY==0) {
            imageView.setScaleX(imageView.getScaleX() * -1);
            velocityX *= -1;
        } else if (x >= pane.getWidth() - imageView.getImage().getWidth() && velocityX>0 && velocityY==0) {
            imageView.setScaleX(imageView.getScaleX() * -1);
            velocityX *= -1;
        }

    }

    public ImageView getImageView() {
        return imageView;
    }

    public String getDuckColor() {
        return duckColor;
    }
    /**
     Stops the animation and movement of the Duck.
     The timeline responsible for the wing animation and the movement timeline are both stopped.
     This method can be called to pause or halt the Duck's animation and movement.
     It does not remove the Duck from the parent pane.
     @autor b2210356023 ilhan aras
     @return void
     */
    public void animationStoper(){
        timeline.stop();
        movement.stop();
    }

    public int getVelocityX() {
        return velocityX;
    }

    public void setVelocityX(int velocityX) {
        this.velocityX = velocityX;
    }

    public int getVelocityY() {
        return velocityY;
    }

    public void setVelocityY(int velocityY) {
        this.velocityY = velocityY;
    }
}
