import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.media.AudioClip;
import javafx.stage.Stage;


public class DuckHunt extends Application {

    public static final double SCALE = 3;
    public static final int WINDOW_WIDTH = (int) (400*SCALE);
    public static final int WINDOW_HEIGHT = (int) (300*SCALE);
    public static final int DUCK_SIZE = WINDOW_WIDTH/12;
    public static final int CROSSHAIRSIZE = WINDOW_WIDTH/25;
    public static final int TEXTSIZE = WINDOW_WIDTH/40;
    public static final double AllMusicsVolume=0.025;

    

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setResizable(false);
        WelcomeScreenClass welcomeScreenClass=new WelcomeScreenClass(primaryStage);
        welcomeScreenClass.start(primaryStage);
    }
}
