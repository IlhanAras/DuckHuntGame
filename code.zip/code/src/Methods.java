import javafx.animation.*;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.util.Duration;


public interface Methods {

    /**
     Creates a flashing text label with two lines of text.
     The label fades in and out repeatedly.
     @param FLASHING_TEXT_LINE_1 The first line of text.
     @param FLASHING_TEXT_LINE_2 The second line of text.
     @return The created flashing text label.
     */
    default Label createFlashingTextLabel(String FLASHING_TEXT_LINE_1, String FLASHING_TEXT_LINE_2) {
        Text text=new Text(FLASHING_TEXT_LINE_1+"\n"+FLASHING_TEXT_LINE_2);
        text.setTextAlignment(TextAlignment.CENTER);
        text.setFill(Color.ORANGE);
        text.setFont(Font.font("Arial", FontWeight.BOLD, DuckHunt.TEXTSIZE+10));
        Label flashingTextLabel = new Label();
        flashingTextLabel.setGraphic(text);
        flashingTextLabel.setTranslateY(DuckHunt.WINDOW_HEIGHT/4.0);

        FadeTransition fadeIn = new FadeTransition(Duration.seconds(1.0), flashingTextLabel);
        fadeIn.setFromValue(0.0);
        fadeIn.setToValue(1.0);
        fadeIn.setCycleCount(Animation.INDEFINITE);
        fadeIn.setAutoReverse(true);
        fadeIn.play();
        return flashingTextLabel;
    }

    /**
     Creates and sets up the crosshair image view for the level scene.
     The crosshair is centered in the window and displayed without the cursor.
     @param lvlScene The level scene.
     @param crosshairImageView The image view for the crosshair.
     @param crosshairOption The option for the crosshair image.
     @param lvlRoot The root pane of the level scene.
     @return The created crosshair image view.
     */
    default ImageView makeCroshairLabel(Scene lvlScene,ImageView crosshairImageView,String crosshairOption,
                                          Pane lvlRoot){
        lvlScene.setCursor(Cursor.NONE);
        crosshairImageView = new ImageView();
        crosshairImageView.setFitWidth(DuckHunt.CROSSHAIRSIZE);
        crosshairImageView.setFitHeight(DuckHunt.CROSSHAIRSIZE);
        crosshairImageView.setTranslateX(DuckHunt.WINDOW_WIDTH / 2 - crosshairImageView.getFitWidth() / 2);
        crosshairImageView.setTranslateY(DuckHunt.WINDOW_HEIGHT / 2 - crosshairImageView.getFitHeight() / 2);
        crosshairImageView.setImage(new Image("assets/crosshair/" +crosshairOption));

        lvlRoot.getChildren().addAll(crosshairImageView);
        return crosshairImageView;
    }

    /**
     Plays the game over sound effect and displays the game over text in the level scene.
     @param lvlRoot The root pane of the level scene.
     @return The AudioClip representing the game over sound effect.
     */
    default AudioClip gameOverTextAndSoundMaker(Pane lvlRoot){
        AudioClip loseEffect = new AudioClip(getClass().getResource("assets/effects/GameOver.mp3").toString());
        loseEffect.setVolume(DuckHunt.AllMusicsVolume);
        loseEffect.play();

        Label flashingTextLabel = createFlashingTextLabel("GAME OVER\nPress ENTER to play again", "Press ESC to exit");
        flashingTextLabel.layoutXProperty().bind(lvlRoot.widthProperty().subtract(flashingTextLabel.widthProperty()).divide(2));
        flashingTextLabel.layoutYProperty().bind(lvlRoot.heightProperty().subtract(flashingTextLabel.heightProperty()).divide(2));

        lvlRoot.getChildren().add(flashingTextLabel);
        return loseEffect;
    }

    /**
     Plays the win sound effect and displays the win text in the level scene.
     @param lvlRoot The root pane of the level scene.
     @return The AudioClip representing the win sound effect.
     */
    default AudioClip gameWinTextAnfSoundMaker(Pane lvlRoot){
        AudioClip winEffect = new AudioClip(getClass().getResource("assets/effects/LevelCompleted.mp3").toString());
        winEffect.setVolume(DuckHunt.AllMusicsVolume);
        winEffect.play();

        Label flashingTextLabel = createFlashingTextLabel("YOU WIN", "Press ENTER to play next level");
        flashingTextLabel.layoutXProperty().bind(lvlRoot.widthProperty().subtract(flashingTextLabel.widthProperty()).divide(2));
        flashingTextLabel.layoutYProperty().bind(lvlRoot.heightProperty().subtract(flashingTextLabel.heightProperty()).divide(2));

        lvlRoot.getChildren().add(flashingTextLabel);
        return winEffect;
    }

    /**
     Creates and sets up the ammo label in the level scene.
     The label displays the current ammo count.
     @param lvlRoot The root pane of the level scene.
     @param ammoCount The current ammo count.
     @return The created ammo label.
     */
    default Label makeAmmoLabel(Pane lvlRoot,int ammoCount){

        Label ammoLabel = new Label();
        ammoLabel.setText("Ammo: "+ammoCount);
        ammoLabel.setFont(Font.font("Arial", FontWeight.BOLD, DuckHunt.TEXTSIZE));
        ammoLabel.setTextFill(Color.ORANGE);
        ammoLabel.setTextAlignment(TextAlignment.CENTER);
        ammoLabel.setLayoutX(DuckHunt.WINDOW_WIDTH/2.0);
        ammoLabel.setLayoutY(0);
        lvlRoot.getChildren().addAll(ammoLabel);
        return ammoLabel;
    }


    /**
     Handles the hit event on a duck.
     Plays the duck falling sound effect, updates the duck's image, and animates its falling motion.
     @param duck The duck that was hit.
     @param lvlRoot The root pane of the level scene.
     */
    default void hitDuck(Duck duck, Pane lvlRoot) {

        AudioClip fallMusic= new AudioClip(getClass().getResource("assets/effects/DuckFalls.mp3").toString());
        fallMusic.setVolume(DuckHunt.AllMusicsVolume);
        fallMusic.play();

        ImageView duckImageView=duck.getImageView();
        if(duck.getVelocityY()>0){
            duckImageView.setScaleY(duckImageView.getScaleY() * -1);
        }
        duck.animationStoper();
        duckImageView.setImage(new Image("assets/"+duck.getDuckColor()+"/7.png"));

        PauseTransition pauseTransition = new PauseTransition(Duration.seconds(0.5));

        pauseTransition.setOnFinished(event -> {
            duckImageView.setImage(new Image("assets/"+duck.getDuckColor()+"/8.png"));

            TranslateTransition fallTransition = new TranslateTransition(Duration.seconds(0.7), duckImageView);
            fallTransition.setByY(DuckHunt.WINDOW_HEIGHT);

            TranslateTransition removeTransition = new TranslateTransition(Duration.seconds(0.5), duckImageView);
            removeTransition.setByY(DuckHunt.WINDOW_HEIGHT);

            removeTransition.setOnFinished(e -> {
                lvlRoot.getChildren().remove(duckImageView);

            });

            SequentialTransition sequentialTransition = new SequentialTransition(fallTransition, removeTransition);
            sequentialTransition.play();
        });
        pauseTransition.play();
    }
}
