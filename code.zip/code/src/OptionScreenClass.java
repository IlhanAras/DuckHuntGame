import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.media.AudioClip;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class OptionScreenClass extends Application {

    private AudioClip backgroundMusic;
    private Stage primaryStage;
    private Pane optionsRoot;
    private Scene optionsScene;
    private int WIDTH, HEIGHT;
    private ImageView backgroundImageView;
    private ImageView crosshairImageView;

    private String[] backgroundOptions = {"1.png", "2.png", "3.png", "4.png", "5.png", "6.png"};
    private String[] crosshairOptions = {"1.png", "2.png", "3.png", "4.png", "5.png", "6.png", "7.png"};

    private int selectedBackgroundIndex = 0;
    private int selectedCrosshairIndex = 0;

    /**
     Creates an instance of the OptionScreenClass.
     @param primaryStage The primary stage of the application.
     @param backgroundMusic The background music AudioClip.
     */
    public OptionScreenClass(Stage primaryStage,AudioClip backgroundMusic) {
        this.primaryStage = primaryStage;
        this.HEIGHT=DuckHunt.WINDOW_HEIGHT;
        this.WIDTH=DuckHunt.WINDOW_WIDTH;
        this.optionsRoot = new Pane();
        this.optionsScene=new Scene(optionsRoot,WIDTH,HEIGHT);
        this.backgroundMusic=backgroundMusic;
        backgroundAndCrosshairSelect();
    }

    /**
     Sets up the background and crosshair selection in the options screen.
     This method initializes the background and crosshair image views, sets their properties,
     and adds them to the options root pane along with the instructions text.
     */
    private void backgroundAndCrosshairSelect(){

        backgroundImageView = new ImageView();
        backgroundImageView.setFitWidth(WIDTH);
        backgroundImageView.setFitHeight(HEIGHT);
        updateBackgroundImage(backgroundImageView, backgroundOptions[selectedBackgroundIndex]);

        crosshairImageView = new ImageView();
        crosshairImageView.setFitWidth(DuckHunt.CROSSHAIRSIZE);
        crosshairImageView.setFitHeight(DuckHunt.CROSSHAIRSIZE);
        crosshairImageView.setTranslateX(WIDTH / 2 - crosshairImageView.getFitWidth() / 2);
        crosshairImageView.setTranslateY(HEIGHT / 2 - crosshairImageView.getFitHeight() / 2);
        crosshairImageView.setImage(new Image("assets/crosshair/1.png"));

        Text instructionsText = new Text("Use arrow keys to navigate options\nPress ENTER to start the game\nPress ESC to go back");
        instructionsText.setFont(Font.font("Arial", FontWeight.BOLD, DuckHunt.TEXTSIZE+5));
        instructionsText.setFill(Color.ORANGE);

        instructionsText.setTextAlignment(TextAlignment.CENTER);
        instructionsText.setLayoutX(WIDTH/4.0);
        instructionsText.setLayoutY(HEIGHT/20);

        optionsRoot.getChildren().addAll(backgroundImageView, crosshairImageView, instructionsText);

    }

    private void updateBackgroundImage(ImageView imageView, String backgroundImageFile) {
        Image backgroundImage = new Image("assets/background/" + backgroundImageFile);
        imageView.setImage(backgroundImage);
    }

    private void updateCrosshairImage(ImageView imageView, String crosshairImageFile) {
        Image crosshairImage = new Image("assets/crosshair/" + crosshairImageFile);
        imageView.setImage(crosshairImage);
    }


    @Override
    public void start(Stage primaryStage) throws Exception {

        optionsScene.setOnKeyPressed(event -> {
            KeyCode keyCode = event.getCode();
            if (keyCode == KeyCode.LEFT) {
                selectedBackgroundIndex = (selectedBackgroundIndex - 1 + backgroundOptions.length) % backgroundOptions.length;
                updateBackgroundImage(backgroundImageView, backgroundOptions[selectedBackgroundIndex]);
            } else if (keyCode == KeyCode.RIGHT) {
                selectedBackgroundIndex = (selectedBackgroundIndex + 1) % backgroundOptions.length;
                updateBackgroundImage(backgroundImageView, backgroundOptions[selectedBackgroundIndex]);
            } else if (keyCode == KeyCode.UP) {
                selectedCrosshairIndex = (selectedCrosshairIndex - 1 + crosshairOptions.length) % crosshairOptions.length;
                updateCrosshairImage(crosshairImageView, crosshairOptions[selectedCrosshairIndex]);
            } else if (keyCode == KeyCode.DOWN) {
                selectedCrosshairIndex = (selectedCrosshairIndex + 1) % crosshairOptions.length;
                updateCrosshairImage(crosshairImageView, crosshairOptions[selectedCrosshairIndex]);
            } else if (keyCode == KeyCode.ENTER) {
                if( backgroundMusic!=null){
                    backgroundMusic.stop();
                }

                AudioClip backgroundMusic = new AudioClip(getClass().getResource("assets/effects/Intro.mp3").toString());
                backgroundMusic.setVolume(DuckHunt.AllMusicsVolume);
                backgroundMusic.play();
                while(backgroundMusic.isPlaying()){}

                Level1Class level1=new Level1Class(primaryStage,1, backgroundOptions[selectedBackgroundIndex], crosshairOptions[selectedCrosshairIndex],1);
                try {
                    level1.start(primaryStage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }

            } else if (keyCode == KeyCode.ESCAPE) {
                if( backgroundMusic!=null){
                    backgroundMusic.stop();
                }

                WelcomeScreenClass welcomeScreenClass=new WelcomeScreenClass(primaryStage);
                try {
                    welcomeScreenClass.start(primaryStage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                crosshairImageView.setVisible(false);
            }
        });

        primaryStage.setScene(optionsScene);
    }
}
